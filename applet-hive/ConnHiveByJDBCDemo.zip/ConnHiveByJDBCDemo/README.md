1、在input.sql文件中输入要执行的sql语句
2、在命令行执行  java ConnHiveByJDBCDemo 
3、成功执行后结果输出在output.csv中